// Hello.h

#ifndef _HELLO_H
#define _HELLO_H

std::string printGameOver();

#endif