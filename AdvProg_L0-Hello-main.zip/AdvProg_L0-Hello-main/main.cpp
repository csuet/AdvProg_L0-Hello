#include <iostream>
#include "hello.h"

int main(){
    std::cout << printGameOver() << std::endl ;
}