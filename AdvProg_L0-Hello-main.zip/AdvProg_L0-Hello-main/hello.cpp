#include <iostream>
#include "hello.h"

std::string printGameOver(){
	// TODO: Return the required string
	return "Game Over!";
}
